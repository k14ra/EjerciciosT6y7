package michel.prog.poo.Tema67_1;

import java.util.ArrayList;
import java.util.List;

public class CajonFacturas {
	private List<Factura> facturas;

	public CajonFacturas() {
		this.facturas = new ArrayList<>();

	}

	public boolean addFactura(Factura fact) {

		if (!this.facturas.contains(fact)) {
			this.facturas.add(fact);

			return true;
		}

		return false;
	}

	public Factura findFactura(int numeroFactura) {

		for (Factura factura : this.facturas) {
			if (factura.getNumeroFactura() == numeroFactura) {
				return factura;
			}
		}
		return null;

	}

	public List<Factura> facturasNoCobradas() {
		List<Factura> facturasNoCobradas = new ArrayList<>();
		for (Factura fac : this.facturas) {
			if (fac.isPagada() == false) {
				facturasNoCobradas.add(fac);
			}

		}
		return facturasNoCobradas;

	}

}
