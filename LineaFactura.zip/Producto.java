package michel.prog.poo.Tema67_1;

import java.util.Objects;

public class Producto {
	private int codigo;
	private int cantidad;
	private int minimo;
	private double precio;
	private String descripcion;
	
	
	public Producto(int codigo, int cantidad, int minimo, double precio, String descripcion) {
		this.codigo = codigo;
		this.cantidad = cantidad;
		this.minimo = minimo;
		this.precio = precio;
		this.descripcion = descripcion;
		
		
		
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	
	public int getMinimo() {
		return minimo;
	}
	public void setMinimo(int minimo) {
		this.minimo = minimo;
	}
	
	
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	@Override
	public int hashCode() {
		return Objects.hash(cantidad, codigo, descripcion, minimo, precio);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		return cantidad == other.cantidad && codigo == other.codigo && Objects.equals(descripcion, other.descripcion)
				&& minimo == other.minimo && Double.doubleToLongBits(precio) == Double.doubleToLongBits(other.precio);
	}
	@Override
	public String toString() {
		return "Stock [codigo=" + codigo + ", cantidad=" + cantidad + ", minimo=" + minimo + ", precio=" + precio
				+ ", descripcion=" + descripcion + "]";
	}
	
	
	
	
	
	
	
	
}

