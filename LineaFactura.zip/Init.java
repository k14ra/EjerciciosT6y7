package michel.prog.poo.Tema67_1;



public class Init {
	public static void main(String[] args) {
		Producto pr = new Producto(433, 0, 2, 29.99, "Sierra de podar");
		Producto pr1 = new Producto(123, 20, 40, 5.99, "Tijeras");
		Producto pr2 = new Producto(221, 0, 10, 2.99, "Pegamento");
		Stock st = new Stock();

//Añadimos los productos que queremos a la lista
		st.addProducto(pr1);
		st.addProducto(pr);
		st.addProducto(pr2);

//Buscamos los productos deseados
		System.out.println();
		System.out.println("Buscamos el producto deseado");
		System.out.println(st.findProducto(433));

//Borramos el producto que queramos
		System.out.println();
		System.out.println("Borramos el producto deseado");
		System.out.println(st.borrarProducto(433));

//Productos agotados
		System.out.println();
		System.out.println("Vemos la lista de los productos que estan agotados");
		System.out.println(st.productosAgotados());

//Lista con los productos bajo minimos
		System.out.println();
		System.out.println("Vemos la lista con los productos que estan bajo minimos");
		System.out.println(st.productosBajoMinimos());

//Pasamos a ver las facturas
		System.out.println();
		System.out.println("FACTURAS");

		Factura fc = new Factura();
		Factura fc2 = new Factura();

//Instanciamos el cajon factura para utilizar los metodos
		CajonFacturas cj = new CajonFacturas();

//Añadimos las facturas que queramos a la lista
		cj.addFactura(fc);
		cj.addFactura(fc2);

//Buscamos las facturas a traves del numero de factura
		System.out.println();
		System.out.println(cj.findFactura(0));
		System.out.println(cj.findFactura(1));

		System.out.println();

//Por ultimo , buscamos las facturas que no se han cobrado
		
		System.out.println("Facturas no cobradas");
		
		System.out.println(cj.facturasNoCobradas());

//Vamos a pagar una factura
		
		Factura fc3=cj.findFactura(4);
		if(fc3!=null) {
			
			fc3.setPagada(true);
		}
		
		
		//Por ultimo , buscamos las facturas que no se han cobrado
		
				System.out.println("Facturas no cobradas");
				
				System.out.println(cj.facturasNoCobradas());

		
	}
	
	

}
