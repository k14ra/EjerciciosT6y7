package michel.prog.poo.Tema67_1;



import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Factura {

	private LocalDateTime fecha;
	private int numeroFactura;
	private static int contadorFactura=0;
	private List<Factura> lineasFactura;
	private boolean pagada;

	
	
	
	public Factura() {
	
		this.fecha = LocalDateTime.now();
		this.numeroFactura=contadorFactura;
		contadorFactura++;
		this.lineasFactura = new ArrayList<>();
		this.pagada = false;

	}



	

/*Getters Setters*/

	public LocalDateTime getFecha() {
		return fecha;
	}







	public void setFecha(LocalDateTime fecha) {
		this.fecha = fecha;
	}







	public int getNumeroFactura() {
		return numeroFactura;
	}







	public void setNumeroFactura(int numeroFactura) {
		this.numeroFactura = numeroFactura;
	}







	public static int getContadorFactura() {
		return contadorFactura;
	}







	public static void setContadorFactura(int contadorFactura) {
		Factura.contadorFactura = contadorFactura;
	}







	public List<Factura> getLineasFactura() {
		return lineasFactura;
	}







	public void setLineasFactura(List<Factura> lineasFactura) {
		this.lineasFactura = lineasFactura;
	}







	public boolean isPagada() {
		return pagada;
	}







	public void setPagada(boolean pagada) {
		this.pagada = pagada;
	}
	
	
	
	







	@Override
	public int hashCode() {
		return Objects.hash(fecha, lineasFactura, numeroFactura, pagada);
	}





	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Factura other = (Factura) obj;
		return Objects.equals(fecha, other.fecha) && Objects.equals(lineasFactura, other.lineasFactura)
				&& numeroFactura == other.numeroFactura && pagada == other.pagada;
	}





	@Override
	public String toString() {
		return "Factura [fecha=" + fecha + ", numeroFactura=" + numeroFactura + ", lineasFactura=" + lineasFactura
				+ ", pagada=" + pagada + "]";
	}
	
	
	
	




	
	
	







	
	
	
	
	
	
	
}


