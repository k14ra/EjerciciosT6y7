package michel.prog.poo.Tema67_1;

import java.util.ArrayList;
import java.util.List;

public class Stock {
	private List<Producto> productos;

	public Stock() {

		this.productos = new ArrayList<>();
	}

	public boolean addProducto(Producto pr) {
		boolean result = false;
		if (!this.productos.contains(pr)) {
			this.productos.add(pr);
			result = true;
			return result;
		}
		return result;
	}

	public Producto findProducto(int codigo) {

		for (Producto elem : this.productos) {
			if (elem.getCodigo() == codigo) {
				return elem;
			}
		}
		return null;
	}

	public boolean borrarProducto(int codigo) {
		for (Producto pro : this.productos) {
			if (pro.getCodigo() == codigo) {
				productos.remove(pro);
				return true;
			}
		}
		return false;
	}
	
	
	public List<Producto> productosAgotados(){
		List<Producto> productosAgotados= new ArrayList<>();
		for (Producto pr :this.productos) {
			if(pr.getCantidad()==0) {
				productosAgotados.add(pr);
	
			}
		}
		return productosAgotados;
	}
	
	/**
	 * @return lista con elementos bajo minimos o si no hay, la retorna vacia (NO ES NULA)
	 */
	public List<Producto> productosBajoMinimos(){
		List<Producto> bajoMinimos= new ArrayList<>();
		for (Producto pr : this.productos) {
			if(pr.getCantidad()<pr.getMinimo()) {
				bajoMinimos.add(pr);
			
			}
		}
		return bajoMinimos;
	}
	


}
